@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
  py -3 reset_admin_password.py
) else (
  python reset_admin_password.py
)

if errorlevel 1 pause
