import { describe, it, expect } from "vitest";
import { detectComputerName } from "@/lib/tickets";

describe("detectComputerName", () => {
  it("usa o ?pc= da URL", () =>
    expect(detectComputerName("?pc=brcps-qd01", null)).toBe("BRCPS-QD01"));
  it("cai para o valor salvo", () => expect(detectComputerName("", "PC-9")).toBe("PC-9"));
  it("vazio quando não há nada", () => expect(detectComputerName("", null)).toBe(""));
});

import { countByMiniFabrica } from "@/lib/tickets";
describe("contagem por mini fábrica", () => {
  it("soma por mini fábrica e ignora chamados sem mini fábrica", () => {
    expect(
      countByMiniFabrica([
        { details: { mini_fabrica: "MFAN" } },
        { details: { mini_fabrica: "MFAN" } },
        { details: { mini_fabrica: "MFSC" } },
        { details: {} },
        { details: null },
      ]),
    ).toEqual({ MFAN: 2, MFSC: 1 });
  });
});

import { SELECTABLE_STATUSES as SEL, STATUS_REQUIRES_NOTE as REQ } from "@/lib/tickets";
describe("regras de status", () => {
  it("em execução retirado e parecer obrigatório", () => {
    expect(SEL).not.toContain("em_execucao");
    expect(REQ).toEqual(["em_andamento", "resolvido", "cancelado"]);
  });
});
