import http.cookiejar
import json
import os
import sqlite3
import sys
import tempfile
import threading
import types
import unittest
from unittest.mock import Mock, patch
from urllib.error import HTTPError
from urllib.request import HTTPCookieProcessor, Request, build_opener

import server
import prepare_outlook
from reset_admin_password import reset_admin_password


class LocalApiTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.previous_data_dir = os.environ.get("QDAS_DATA_DIR")
        self.previous_setup_token = os.environ.get("FIRST_ADMIN_SETUP_TOKEN")
        os.environ["QDAS_DATA_DIR"] = self.temp_dir.name
        self.setup_token = "test-only-token-for-local-api-test-1234567890"
        os.environ["FIRST_ADMIN_SETUP_TOKEN"] = self.setup_token
        server.initialize_database()
        self.notification_patcher = patch.object(server, "enviar_notificacao_chamado")
        self.notification_mock = self.notification_patcher.start()
        self.addCleanup(self.notification_patcher.stop)
        self.httpd = server.QdasServer(("127.0.0.1", 0), server.QdasHandler)
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()
        self.base_url = f"http://127.0.0.1:{self.httpd.server_port}"
        self.opener = build_opener(HTTPCookieProcessor(http.cookiejar.CookieJar()))

    def tearDown(self):
        self.httpd.shutdown()
        self.httpd.server_close()
        self.thread.join(timeout=3)
        if self.previous_data_dir is None:
            os.environ.pop("QDAS_DATA_DIR", None)
        else:
            os.environ["QDAS_DATA_DIR"] = self.previous_data_dir
        if self.previous_setup_token is not None:
            os.environ["FIRST_ADMIN_SETUP_TOKEN"] = self.previous_setup_token
        else:
            os.environ.pop("FIRST_ADMIN_SETUP_TOKEN", None)
        self.temp_dir.cleanup()

    def request(self, method, path, body=None, expected=200):
        data = json.dumps(body).encode("utf-8") if body is not None else None
        request = Request(
            self.base_url + path,
            data=data,
            method=method,
            headers={"Content-Type": "application/json"} if data is not None else {},
        )
        try:
            response = self.opener.open(request)
        except HTTPError as error:
            response = error
        payload = json.loads(response.read())
        self.assertEqual(response.status, expected, payload)
        return payload

    def test_setup_login_and_ticket_lifecycle(self):
        self.assertEqual(self.request("GET", "/api/health"), {"ok": True})
        self.assertEqual(self.request("GET", "/api/setup"), {"has_access": False})
        self.request(
            "POST",
            "/api/setup",
            {"name": "Admin", "np": "admin01", "password": "1234", "setupToken": "wrong"},
            expected=403,
        )
        self.request(
            "POST",
            "/api/setup",
            {
                "name": "Admin",
                "np": "admin01",
                "password": "1234",
                "setupToken": self.setup_token,
            },
        )
        self.assertFalse(server.token_file_path().exists())
        self.request(
            "POST",
            "/api/setup",
            {
                "name": "Other Admin",
                "np": "admin02",
                "password": "1234",
                "setupToken": self.setup_token,
            },
            expected=409,
        )

        self.request("GET", "/api/tickets", expected=401)

        login = self.request("POST", "/api/login", {"np": "ADMIN01", "password": "1234"})
        self.assertTrue(login["user"]["admin"])
        self.assertTrue(login["user"]["support"])
        self.assertEqual(self.request("GET", "/api/me")["user"]["np"], "admin01")

        def verify_notification_runs_after_commit(chamado):
            with server.db_connection() as db:
                saved_ticket = db.execute(
                    "SELECT number FROM tickets WHERE number = ?", (chamado["number"],)
                ).fetchone()
                self.assertIsNotNone(saved_ticket)

        self.notification_mock.side_effect = verify_notification_runs_after_commit
        ticket = self.request(
            "POST",
            "/api/tickets",
            {
                "computer_name": "PC-01",
                "ticket_type": "instalacao",
                "requester_name": "Solicitante",
                "description": "",
                "privacy_consent": {
                    "accepted": True,
                    "version": server.PRIVACY_POLICY_VERSION,
                },
                "details": {
                    "computer_name_maquina": "PC-01",
                    "operacao": "Montagem",
                    "bp": "12345",
                    "mini_fabrica": "MFAN",
                },
            },
        )
        self.assertEqual(ticket["number"], 1)
        self.notification_mock.assert_called_once()
        notified_ticket = self.notification_mock.call_args.args[0]
        self.assertEqual(notified_ticket["title"], "Solicitar instalação")
        self.assertNotIn("priority", notified_ticket)
        with server.db_connection() as db:
            saved_consent = db.execute(
                "SELECT privacy_policy_version, privacy_accepted_at FROM tickets WHERE number = ?",
                (ticket["number"],),
            ).fetchone()
            self.assertEqual(saved_consent["privacy_policy_version"], server.PRIVACY_POLICY_VERSION)
            self.assertTrue(saved_consent["privacy_accepted_at"])
        public = self.request("GET", "/api/computers/PC-01/tickets")
        self.assertEqual(len(public), 1)
        self.assertEqual(
            set(public[0]),
            {"number", "ticket_type", "status", "created_at", "public_notes"},
        )
        self.assertEqual(public[0]["public_notes"], [])

        records = self.request("GET", "/api/tickets")
        ticket_id = records[0]["id"]
        self.assertEqual(
            records[0]["privacy_policy_version"], server.PRIVACY_POLICY_VERSION
        )
        self.assertEqual(
            records[0]["privacy_accepted_at"], saved_consent["privacy_accepted_at"]
        )
        self.request(
            "PATCH",
            f"/api/tickets/{ticket_id}",
            {"status": "resolvido", "assignee": "Admin", "support_notes": ""},
            expected=400,
        )
        self.request(
            "PATCH",
            f"/api/tickets/{ticket_id}",
            {"status": "em_andamento", "assignee": "Admin", "support_notes": "Em análise"},
        )
        self.request(
            "PATCH",
            f"/api/tickets/{ticket_id}",
            {"status": "em_andamento", "assignee": "Admin", "support_notes": ""},
        )
        self.assertEqual(self.request("GET", "/api/tickets")[0]["status"], "em_andamento")
        self.request(
            "PATCH",
            f"/api/tickets/{ticket_id}",
            {
                "status": "resolvido",
                "assignee": "Admin",
                "support_notes": "Resolvido",
                "note_is_public": True,
            },
        )
        staff_ticket = self.request("GET", "/api/tickets")[0]
        self.assertTrue(staff_ticket["status_history"][-1]["is_public"])
        self.assertEqual(
            [entry["note"] for entry in staff_ticket["status_history"]],
            ["Em análise", "Resolvido"],
        )
        public = self.request("GET", "/api/computers/PC-01/tickets")
        self.assertEqual(public[0]["status"], "resolvido")
        self.assertEqual(
            set(public[0]),
            {"number", "ticket_type", "status", "created_at", "public_notes"},
        )
        self.assertEqual(
            public[0]["public_notes"],
            [{"note": "Resolvido", "changed_at": staff_ticket["status_history"][-1]["changed_at"]}],
        )
        self.request(
            "PATCH",
            f"/api/tickets/{ticket_id}",
            {"status": "aberto", "assignee": "Admin", "support_notes": ""},
        )
        staff_ticket = self.request("GET", "/api/tickets")[0]
        self.assertEqual(staff_ticket["support_notes"], "Resolvido")
        self.assertEqual(
            [entry["note"] for entry in staff_ticket["status_history"]],
            ["Em análise", "Resolvido", None],
        )

        self.request(
            "POST",
            "/api/mini-fabricas",
            {"name": " mf-nova "},
        )
        self.assertIn("MF-NOVA", self.request("GET", "/api/mini-fabricas"))
        self.request(
            "POST",
            "/api/users",
            {"name": "Suporte", "np": "suporte1", "password": "1234", "admin": False},
        )
        self.assertEqual(len(self.request("GET", "/api/users")), 2)

        self.request("POST", "/api/logout", {})
        self.assertIsNone(self.request("GET", "/api/me")["user"])
        self.request("GET", "/api/tickets", expected=401)

    def test_admin_can_configure_ticket_types_and_optional_fields(self):
        body = {
            "label": "Acesso especial",
            "hint": "Solicitação personalizada",
            "fields": [
                {"key": "aplicacao", "label": "Aplicação", "required": True},
                {"key": "detalhe_extra", "label": "Detalhe extra", "required": False},
            ],
            "description_required": False,
        }
        self.request("POST", "/api/ticket-types", body, expected=401)
        self.request("DELETE", "/api/ticket-types/outros", expected=401)
        self.request(
            "POST",
            "/api/setup",
            {
                "name": "Admin",
                "np": "admin01",
                "password": "1234",
                "setupToken": self.setup_token,
            },
        )
        self.request("POST", "/api/login", {"np": "admin01", "password": "1234"})
        created = self.request("POST", "/api/ticket-types", body)
        self.assertEqual(created["id"], "acesso_especial")
        self.assertEqual(created["fields"][1]["required"], False)
        ticket = {
            "computer_name": "PC-02",
            "ticket_type": created["id"],
            "requester_name": "",
            "description": "",
            "privacy_consent": {
                "accepted": True,
                "version": server.PRIVACY_POLICY_VERSION,
            },
            "details": {"aplicacao": "Q-DAS", "mini_fabrica": "MFAN"},
        }
        created_ticket = self.request("POST", "/api/tickets", ticket)
        self.assertEqual(created_ticket["number"], 1)
        self.request("DELETE", f"/api/ticket-types/{created['id']}", expected=409)
        ticket["details"] = {"mini_fabrica": "MFAN"}
        self.request("POST", "/api/tickets", ticket, expected=400)
        ticket["details"] = {
            "aplicacao": "Q-DAS",
            "campo_nao_configurado": "inválido",
            "mini_fabrica": "MFAN",
        }
        self.request("POST", "/api/tickets", ticket, expected=400)

        updated = {**body, "fields": [{**body["fields"][0], "required": False}]}
        self.request("PUT", f"/api/ticket-types/{created['id']}", updated)
        self.assertEqual(
            next(
                item for item in self.request("GET", "/api/ticket-types")
                if item["id"] == created["id"]
            )["fields"][0]["required"],
            False,
        )
        removable = self.request(
            "POST",
            "/api/ticket-types",
            {
                "label": "Tipo temporário",
                "hint": "",
                "fields": [],
                "description_required": False,
            },
        )
        self.request("DELETE", f"/api/ticket-types/{removable['id']}")
        self.assertNotIn(
            removable["id"],
            [item["id"] for item in self.request("GET", "/api/ticket-types")],
        )

    def test_ticket_requires_current_privacy_policy_acceptance(self):
        body = {
            "computer_name": "PC-01",
            "ticket_type": "instalacao",
            "requester_name": "",
            "description": "",
            "details": {
                "computer_name_maquina": "PC-01",
                "operacao": "Montagem",
                "bp": "12345",
                "mini_fabrica": "MFAN",
            },
        }
        self.request("POST", "/api/tickets", body, expected=400)
        body["privacy_consent"] = {"accepted": True, "version": "old-version"}
        self.request("POST", "/api/tickets", body, expected=400)
        with server.db_connection() as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM tickets").fetchone()[0], 0)

    def test_qdas_inativo_requires_description_and_can_be_created(self):
        body = {
            "computer_name": "PC-01",
            "ticket_type": "qdas_inativo",
            "requester_name": "",
            "description": "",
            "privacy_consent": {
                "accepted": True,
                "version": server.PRIVACY_POLICY_VERSION,
            },
            "details": {"mini_fabrica": "MFAN"},
        }
        self.request("POST", "/api/tickets", body, expected=400)
        body["description"] = "O Q-DAS não inicia nesta máquina."
        created = self.request("POST", "/api/tickets", body)
        ticket = self.request("GET", "/api/computers/PC-01/tickets")[0]
        self.assertEqual(ticket["number"], created["number"])
        with server.db_connection() as db:
            row = db.execute(
                "SELECT ticket_type, description FROM tickets WHERE number = ?",
                (created["number"],),
            ).fetchone()
            self.assertEqual(row["ticket_type"], "qdas_inativo")
            self.assertEqual(row["description"], body["description"])

    def test_existing_database_migration_preserves_tickets(self):
        original_data_dir = os.environ["QDAS_DATA_DIR"]
        migration_dir = tempfile.TemporaryDirectory()
        try:
            os.environ["QDAS_DATA_DIR"] = migration_dir.name
            legacy_db = sqlite3.connect(server.database_path())
            try:
                legacy_db.execute(
                    """CREATE TABLE tickets (
                        id TEXT NOT NULL UNIQUE,
                        number INTEGER PRIMARY KEY AUTOINCREMENT,
                        computer_name TEXT NOT NULL,
                        ticket_type TEXT NOT NULL,
                        requester_name TEXT,
                        description TEXT,
                        details TEXT NOT NULL DEFAULT '{}',
                        status TEXT NOT NULL DEFAULT 'aberto',
                        assignee TEXT,
                        support_notes TEXT,
                        created_at TEXT NOT NULL,
                        updated_at TEXT NOT NULL
                    )"""
                )
                legacy_db.execute(
                    """INSERT INTO tickets
                       (id, computer_name, ticket_type, support_notes, created_at, updated_at)
                       VALUES ('existing-ticket', 'PC-OLD', 'outros', 'Parecer legado',
                               '2026-01-01', '2026-01-01')"""
                )
                legacy_db.commit()
            finally:
                legacy_db.close()

            server.initialize_database()

            with server.db_connection() as db:
                columns = {row["name"] for row in db.execute("PRAGMA table_info(tickets)")}
                ticket = db.execute(
                    "SELECT id, computer_name FROM tickets WHERE id = 'existing-ticket'"
                ).fetchone()
                self.assertIn("privacy_policy_version", columns)
                self.assertIn("privacy_accepted_at", columns)
                self.assertEqual(ticket["computer_name"], "PC-OLD")
                history = db.execute(
                    """SELECT note, is_public, changed_by FROM ticket_status_history
                       WHERE ticket_id = 'existing-ticket'"""
                ).fetchone()
                self.assertEqual(history["note"], "Parecer legado")
                self.assertEqual(history["is_public"], 0)
                self.assertEqual(history["changed_by"], "Sistema")
        finally:
            os.environ["QDAS_DATA_DIR"] = original_data_dir
            migration_dir.cleanup()

    @unittest.skipUnless(
        (server.ROOT / "dist" / "index.html").is_file(), "interface ainda não compilada"
    )
    def test_static_app_and_deep_link(self):
        response = self.opener.open(self.base_url + "/suporte")
        self.assertIn("text/html", response.headers.get("Content-Type", ""))
        self.assertIn(b'<div id="root"></div>', response.read())
        response = self.opener.open(self.base_url + "/politica-privacidade.html")
        self.assertIn("text/html", response.headers.get("Content-Type", ""))
        self.assertIn(server.PRIVACY_POLICY_VERSION.encode(), response.read())

    def test_computer_detection_uses_reverse_dns_name(self):
        with patch.object(server.socket, "gethostbyaddr", return_value=("pc-fabrica.corp.local", [], [])) as lookup:
            self.assertEqual(server.resolve_client_computer_name("10.20.30.40"), "PC-FABRICA")
        lookup.assert_called_once_with("10.20.30.40")

    def test_computer_detection_skips_loopback_and_failed_dns(self):
        self.assertIsNone(server.resolve_client_computer_name("127.0.0.1"))
        with patch.object(server.socket, "gethostbyaddr", side_effect=OSError("no reverse DNS")):
            self.assertIsNone(server.resolve_client_computer_name("10.20.30.40"))

    def test_reset_admin_password_preserves_user_and_allows_login(self):
        admin_id = self.request(
            "POST",
            "/api/setup",
            {
                "name": "Admin",
                "np": "admin01",
                "password": "1234",
                "setupToken": self.setup_token,
            },
        )
        self.assertEqual(admin_id, {"ok": True})

        reset_admin_password(" ADMIN01 ", "5678")

        self.assertTrue(self.request("POST", "/api/login", {"np": "admin01", "password": "5678"})["user"]["admin"])
        with server.db_connection() as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM users").fetchone()[0], 1)

    def test_reset_admin_password_rejects_unknown_admin_np(self):
        with self.assertRaisesRegex(ValueError, "conta administradora"):
            reset_admin_password("unknown1", "5678")


class EmailNotificationTests(unittest.TestCase):
    def test_notification_log_records_timestamp_recipient_and_result(self):
        with tempfile.TemporaryDirectory() as temp_dir, patch.dict(
            os.environ, {"QDAS_DATA_DIR": temp_dir}
        ):
            server._log_email_notification(server.NOTIFICATION_RECIPIENTS, success=True)
            server._log_email_notification(
                server.NOTIFICATION_RECIPIENTS,
                success=False,
                error=RuntimeError("Outlook indisponível"),
            )
            log_path = os.path.join(temp_dir, "logs", "email_notifications.log")
            try:
                with open(log_path, encoding="utf-8") as log_file:
                    contents = log_file.read()
            finally:
                logger = server.logging.getLogger("qdas.email_notifications")
                for handler in list(logger.handlers):
                    if getattr(handler, "baseFilename", None) == os.path.abspath(log_path):
                        logger.removeHandler(handler)
                        handler.close()

        self.assertIn("nikolas.souza@fts.org.br", contents)
        self.assertIn("sucesso", contents)
        self.assertIn("erro=Outlook indisponível", contents)
        self.assertRegex(
            contents, r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[+-]\d{2}:\d{2}"
        )

    def test_outlook_notification_sends_html_and_logs_success(self):
        sent_messages = []

        class FakeMail:
            def Send(self):
                sent_messages.append(self)

        class FakeOutlook:
            def CreateItem(self, item_type):
                self.assert_item_type = item_type
                return FakeMail()

        outlook = FakeOutlook()
        pythoncom = types.SimpleNamespace(CoInitialize=lambda: None, CoUninitialize=lambda: None)
        win32com_client = types.SimpleNamespace(Dispatch=lambda name: outlook)
        win32com = types.ModuleType("win32com")
        win32com.client = win32com_client
        with (
            patch.dict(
                sys.modules,
                {
                    "pythoncom": pythoncom,
                    "win32com": win32com,
                    "win32com.client": win32com_client,
                },
            ),
            patch.dict(os.environ, {"QDAS_PUBLIC_URL": "http://qdas.interno:8000"}),
            patch.object(server, "_log_email_notification") as log_notification,
        ):
            server.enviar_notificacao_chamado(
                {
                    "number": 42,
                    "title": "Instalação <Q-DAS>",
                    "requester_name": "Solicitante",
                    "created_at": "2026-11-11T12:30:00Z",
                    "description": "<script>alert(1)</script>",
                }
            )

        self.assertEqual(len(sent_messages), 1)
        message = sent_messages[0]
        self.assertEqual(message.To, "nikolas.souza@fts.org.br")
        self.assertEqual(message.Subject, "[NOVO CHAMADO] #42 - Instalação <Q-DAS>")
        self.assertNotIn("Prioridade", message.HTMLBody)
        self.assertNotIn("Não informada", message.HTMLBody)
        self.assertIn("&lt;script&gt;", message.HTMLBody)
        self.assertNotIn("<script>", message.HTMLBody)
        self.assertIn("http://qdas.interno:8000/", message.HTMLBody)
        log_notification.assert_called_once_with(server.NOTIFICATION_RECIPIENTS, success=True)

    def test_outlook_failure_is_logged_and_does_not_raise(self):
        class FakeOutlook:
            def CreateItem(self, item_type):
                raise RuntimeError("Outlook indisponível")

        pythoncom = types.SimpleNamespace(CoInitialize=lambda: None, CoUninitialize=lambda: None)
        win32com_client = types.SimpleNamespace(Dispatch=lambda name: FakeOutlook())
        win32com = types.ModuleType("win32com")
        win32com.client = win32com_client
        with (
            patch.dict(
                sys.modules,
                {
                    "pythoncom": pythoncom,
                    "win32com": win32com,
                    "win32com.client": win32com_client,
                },
            ),
            patch.object(server, "_log_email_notification") as log_notification,
        ):
            server.enviar_notificacao_chamado({"number": 7, "title": "Teste"})

        log_notification.assert_called_once()
        self.assertEqual(
            log_notification.call_args.args, (server.NOTIFICATION_RECIPIENTS,)
        )
        self.assertFalse(log_notification.call_args.kwargs["success"])
        self.assertIsInstance(log_notification.call_args.kwargs["error"], RuntimeError)


class PrepareOutlookTests(unittest.TestCase):
    def test_start_outlook_opens_inbox_and_releases_com(self):
        explorer = types.SimpleNamespace(Display=lambda: None)
        inbox = types.SimpleNamespace(GetExplorer=lambda: explorer)
        namespace = types.SimpleNamespace(GetDefaultFolder=lambda folder_id: inbox)
        outlook = types.SimpleNamespace(GetNamespace=lambda name: namespace)
        pythoncom = types.SimpleNamespace(
            CoInitialize=Mock(), CoUninitialize=Mock()
        )
        with (
            patch.object(prepare_outlook.sys, "platform", "win32"),
            patch.object(
                prepare_outlook, "_load_outlook_com", return_value=(pythoncom, lambda name: outlook)
            ) as load_com,
            patch.object(explorer, "Display") as display,
        ):
            prepare_outlook.start_outlook()

        load_com.assert_called_once()
        pythoncom.CoInitialize.assert_called_once()
        pythoncom.CoUninitialize.assert_called_once()
        display.assert_called_once()

    def test_start_outlook_rejects_non_windows(self):
        with patch.object(prepare_outlook.sys, "platform", "linux"):
            with self.assertRaisesRegex(RuntimeError, "Windows"):
                prepare_outlook.start_outlook()


if __name__ == "__main__":
    unittest.main()
