import { describe, expect, it } from "vitest";
import { normalizeNp } from "@/lib/np";

describe("identificação de acesso por NP", () => {
  it("normaliza o NP usado no login local", () => {
    expect(normalizeNp("  AB-123  ")).toBe("ab-123");
  });

  it("rejeita identificadores fora do formato permitido", () => {
    expect(normalizeNp("a")).toBe("");
    expect(normalizeNp("np com espaço")).toBe("");
    expect(normalizeNp("x".repeat(41))).toBe("");
  });
});
