from __future__ import annotations

import getpass
import os
import sys

import server


def read_password(prompt: str) -> str:
    if os.name != "nt":
        return getpass.getpass(prompt)

    import msvcrt

    sys.stdout.write(prompt)
    sys.stdout.flush()
    characters = []
    while True:
        character = msvcrt.getwch()
        if character in ("\r", "\n"):
            sys.stdout.write("\n")
            sys.stdout.flush()
            return "".join(characters)
        if character == "\003":
            raise KeyboardInterrupt
        if character in ("\b", "\x7f"):
            if characters:
                characters.pop()
                sys.stdout.write("\b \b")
                sys.stdout.flush()
            continue
        if character in ("\x00", "\xe0"):
            msvcrt.getwch()
            continue
        if character.isprintable():
            characters.append(character)
            sys.stdout.write("*")
            sys.stdout.flush()


def reset_admin_password(np: str, password: str) -> None:
    normalized_np = server.normalize_np(np)
    if not normalized_np:
        raise ValueError("NP inválido (use letras e números).")
    if not isinstance(password, str) or not 4 <= len(password) <= 128:
        raise ValueError("A senha deve ter entre 4 e 128 caracteres.")
    if not server.database_path().is_file():
        raise FileNotFoundError(f"Banco local não encontrado: {server.database_path()}")

    salt, digest = server.hash_password(password)
    with server.db_connection() as db:
        user = db.execute(
            """SELECT u.id FROM users u
               JOIN user_roles r ON r.user_id = u.id AND r.role = 'admin'
               WHERE u.np = ? COLLATE NOCASE""",
            (normalized_np,),
        ).fetchone()
        if user is None:
            raise ValueError("Não foi encontrada uma conta administradora com esse NP.")
        db.execute(
            "UPDATE users SET password_salt = ?, password_hash = ? WHERE id = ?",
            (salt, digest, user["id"]),
        )


def main() -> int:
    print(f"Banco usado: {server.database_path()}")
    print("A redefinição só altera a senha de uma conta que já seja administradora.")
    np = input("NP do administrador: ").strip()
    password = read_password("Nova senha (4 a 128 caracteres): ")
    confirmation = read_password("Confirme a nova senha: ")
    if password != confirmation:
        print("As senhas não conferem.", file=sys.stderr)
        return 1
    try:
        reset_admin_password(np, password)
    except (OSError, ValueError) as error:
        print(f"Não foi possível redefinir a senha: {error}", file=sys.stderr)
        return 1
    print("Senha redefinida. Entre novamente no sistema com o NP e a nova senha.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
