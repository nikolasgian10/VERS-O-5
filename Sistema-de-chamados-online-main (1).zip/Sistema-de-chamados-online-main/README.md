# MAHLE | Chamados Q-DAS — instalação local

Aplicação de chamados que roda na rede interna da empresa sem Supabase, Vercel ou um serviço de banco de dados separado. O servidor Python serve a interface e a API; o SQLite guarda tudo em um arquivo local no servidor.

```text
Navegadores da fábrica → servidor Python → arquivo SQLite no próprio servidor
```

Os computadores dos funcionários só precisam de um navegador. O arquivo do banco **não** deve ser compartilhado nem aberto diretamente por outros computadores.

## Teste em um computador

Requisitos para compilar a interface: Node.js/npm. Requisito para executar a aplicação: Python 3.10 ou superior. Para notificações pelo Outlook, o servidor também precisa ser Windows e ter o Outlook clássico configurado para a mesma conta Windows que executa `start_server.bat`. A inicialização tenta instalar `pywin32` quando necessário e abrir o Outlook; se não conseguir, inicia o servidor mesmo assim e registra a falha em `data\logs\outlook_startup.log`.

1. Abra o terminal nesta pasta e compile a interface:

   ```powershell
   npm install
   npm run build
   ```

2. Inicie o servidor:

   ```powershell
   .\start_server.bat
   ```

   O arquivo abre uma janela separada para o servidor, aguarda a API responder e então abre o navegador em `http://localhost:8000`. Mantenha a janela do servidor aberta enquanto usar o sistema. Ou, se preferir, execute `py -3 server.py` e acesse o endereço manualmente.

3. Na primeira execução, o terminal mostra um código de configuração do administrador. Guarde-o; ele também fica temporariamente em `data\first_admin_setup_token.txt`.
4. No navegador deste mesmo computador, abra `http://localhost:8000/suporte`, cadastre o primeiro administrador com esse código e entre com NP e senha. `0.0.0.0` é o endereço de escuta do servidor e não deve ser digitado no navegador.
5. Teste a abertura de um chamado em `http://localhost:8000`, a gestão em `/suporte` e o cadastro de outro usuário de suporte.
6. Pare o servidor com `Ctrl+C`. Chamados e usuários permanecem no arquivo `data\qdas.sqlite3`.

Na área de gestão, administradores podem criar, editar e excluir tipos de chamado, configurar campos adicionais obrigatórios ou opcionais e definir se a descrição é obrigatória. Tipos já associados a chamados não podem ser excluídos para preservar os registros. Ao atualizar o status de um chamado, os pareceres são adicionados ao histórico, sem apagar os anteriores. Cada parecer pode ser marcado como público ou privado; somente os públicos aparecem em “Chamados deste computador”, e os registros antigos permanecem privados por padrão. Nos detalhes do chamado, a equipe também pode consultar a versão da Política de Privacidade aceita e o horário do registro.

Após gravar um novo chamado, o servidor envia uma notificação HTML pelo Outlook instalado no Windows para `nikolas.souza@fts.org.br`, sem SMTP ou senha. `start_server.bat` define `QDAS_PUBLIC_URL` como `http://<nome deste computador>:8000`; se o endereço da empresa for diferente, configure `QDAS_PUBLIC_URL` antes de iniciar o arquivo. O envio é registrado em `data\logs\email_notifications.log`; falhas no Outlook são registradas sem cancelar a abertura do chamado.

Na primeira utilização, abra o Outlook clássico manualmente, conclua a configuração da conta corporativa e confirme que consegue enviar um e-mail. Depois, inicie o sistema com `start_server.bat` na mesma sessão do Windows e mantenha essa sessão ativa. O novo Outlook não oferece a automação COM usada pelo sistema; rodar o servidor como serviço do Windows ou em outra conta também impede o acesso ao perfil Outlook dessa sessão.

O SQLite e a API usam apenas a biblioteca padrão do Python; não há dependências Python para instalar.

O navegador não pode ler diretamente o nome ou o serial do computador por segurança. Para preencher o nome Windows da estação sem depender de DNS reverso, a TI pode distribuir o arquivo `abrir_qdas_cliente.bat` em cada computador:

1. Edite o arquivo e troque `http://NOME-DO-SERVIDOR:8000` pelo endereço real do servidor, sem barra no final.
2. Copie o arquivo para os computadores clientes ou disponibilize-o em um compartilhamento interno aprovado.
3. O funcionário abre o Q-DAS pelo `abrir_qdas_cliente.bat`. O iniciador passa o valor de `%COMPUTERNAME%` na URL, e o formulário preenche o nome automaticamente.

Esse arquivo é executado em cada estação cliente e não substitui `start_server.bat`, que continua sendo iniciado no servidor. Os funcionários não precisam de Node.js/npm. Se a empresa preferir, a TI pode criar um atalho para esse iniciador na área de trabalho ou configurá-lo pelo método corporativo de distribuição de software. A identificação antiga por DNS reverso continua disponível se o usuário abrir o endereço diretamente.

## Recuperar acesso do administrador

Se a tela de primeiro cadastro não aparecer, isso significa que o banco já contém um usuário. Não apague `data\qdas.sqlite3`: ele guarda os chamados e os usuários. Para recuperar a senha do administrador:

1. Pare o servidor com `Ctrl+C`.
2. Execute `reset_admin_password.bat` na pasta da aplicação.
3. Informe o NP da conta administradora e uma nova senha duas vezes. A senha é digitada sem aparecer na tela.
4. Reinicie `start_server.bat` e entre em `/suporte` com o NP e a nova senha.

O script só redefine senha de uma conta já marcada como administradora e não altera chamados. Se `QDAS_DATA_DIR` estiver configurada, defina o mesmo local antes de executar o script.

## Instalação no servidor da empresa

Peça à TI para aprovar um computador/servidor que fique ligado durante o uso, com nome ou IP estável na rede interna. Combine previamente a porta, as regras de firewall, HTTPS e o local autorizado para os dados.

1. Em um computador de desenvolvimento com Node.js, execute `npm install` e `npm run build`.
2. Copie para uma pasta aprovada no servidor:
   - `server.py`;
   - `start_server.bat`, `reset_admin_password.py`, `reset_admin_password.bat`, `backup_database.py` e `backup_database.bat`;
   - a pasta `dist` gerada pela compilação.
3. Instale/valide Python 3.10+ no servidor. Não é necessário instalar Node.js no servidor.
4. Inicie `start_server.bat`. Por padrão, o Python escuta na porta `8000` em todas as interfaces de rede.
5. Peça à TI para liberar **somente na rede interna necessária** o acesso TCP à porta escolhida e configurar HTTPS. Não exponha esta aplicação diretamente à Internet.
6. Os usuários acessam `http://NOME-DO-SERVIDOR:8000` (ou o endereço HTTPS definido pela TI). O link `/suporte` abre a área de gestão.
7. Cadastre o primeiro administrador usando o código exibido no console do servidor. Não compartilhe esse código em chats ou com usuários finais.
8. Configure o Windows para iniciar o servidor após reinicializações e para não suspender o computador. Essa configuração deve ser feita/aprovada pela TI.

### Onde ficam os dados

Por padrão, o banco e os dados da configuração inicial ficam em `data` ao lado de `server.py`. Para usar uma pasta de dados aprovada pela TI, configure a variável de ambiente `QDAS_DATA_DIR` **antes** de iniciar o servidor. Mantenha essa pasta acessível apenas à conta do serviço/administradores e não aponte para uma pasta de rede compartilhada.

Para HTTPS terminado em um proxy reverso aprovado pela TI, configure `QDAS_COOKIE_SECURE=1` e `QDAS_PUBLIC_SCHEME=https` no ambiente do Python. Não habilite a opção `QDAS_COOKIE_SECURE` se os navegadores estiverem acessando diretamente por HTTP, pois o navegador não enviará o cookie de sessão.

### Backup e recuperação

- Execute `backup_database.bat` para criar uma cópia consistente do SQLite em `data\backups` (ou em `<QDAS_DATA_DIR>\backups`).
- Agende esse script no Windows Task Scheduler conforme a política de retenção da empresa.
- Copie backups para um destino separado e aprovado pela TI. Um backup salvo apenas no mesmo disco não protege contra falha desse disco.
- Para restaurar, pare o servidor, preserve uma cópia do banco atual e substitua `qdas.sqlite3` por uma cópia validada do backup. Depois reinicie e teste o login e os chamados.

## Testes automatizados

```powershell
py -3 -m unittest discover -s tests_python
npm test
npx tsc --noEmit
npm run build
```

O teste Python inicia um servidor temporário e verifica a configuração inicial, login, permissões, catálogo de tipos configurável, aceite e registro da Política de Privacidade, migração sem perda de chamados, abertura/consulta/atualização de chamados, histórico de pareceres e restrição dos dados públicos da consulta por computador.

## Limitações e segurança

- O sistema cria um banco local novo; **os chamados e usuários que já existam no Supabase não são importados automaticamente**. Antes de trocar o sistema em produção, exporte/migre os dados necessários e teste-os em uma cópia.
- O arquivo `.env` da instalação antiga não é usado por esta versão local e não deve ser copiado para o servidor.
- As senhas são armazenadas com PBKDF2 e as sessões usam cookies HttpOnly. Mesmo assim, o tráfego HTTP simples não criptografa senhas ou dados em trânsito: use HTTPS aprovado pela TI para uso real na fábrica.
- SQLite é apropriado para um sistema de chamados pequeno/médio com um único servidor. O servidor Python é o único processo que acessa o arquivo; não mova o banco para uma pasta compartilhada para vários servidores.
- Faça um teste com várias estações e valide firewall, reinicialização, backup e restauração antes da entrada em produção.
- O formulário registra que o solicitante leu o [Aviso de Privacidade](./public/politica-privacidade.html), incluindo a versão e o horário. Essa ciência não define, por si só, a base legal. O documento é uma minuta baseada no funcionamento atual do aplicativo, não uma política oficial da MAHLE; antes do uso oficial, a empresa deve preencher controlador e contato, definir base legal e retenção e obter aprovação de Privacidade/Encarregado, Jurídico, Segurança da Informação e TI.

## Desenvolvimento

```powershell
npm run dev
py -3 server.py
```

Em desenvolvimento, o Vite serve a interface na porta `8080` e encaminha `/api` ao Python na porta `8000`.
