import { apiRequest, postJson } from "@/lib/api";

type Credentials = { np: string; password: string; name: string };
type UserSummary = { id: string; np: string; name: string; admin: boolean };

export async function hasAnyAccess(): Promise<boolean> {
  const result = await apiRequest<{ has_access: boolean }>("/setup");
  return result.has_access;
}

export function setupFirstAdmin({ data }: { data: Credentials & { setupToken: string } }) {
  return postJson<{ ok: boolean }>("/setup", data);
}

export function listSupportUsers(): Promise<UserSummary[]> {
  return apiRequest("/users");
}

export function createSupportUser({ data }: { data: Credentials & { admin?: boolean } }) {
  return postJson<{ ok: boolean }>("/users", data);
}

export function removeSupportUser({ data }: { data: { id: string } }) {
  return apiRequest<{ ok: boolean }>(`/users/${encodeURIComponent(data.id)}`, {
    method: "DELETE",
  });
}
