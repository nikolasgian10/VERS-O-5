from __future__ import annotations

import os
import sqlite3
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("QDAS_DATA_DIR", ROOT / "data")).resolve()
SOURCE = DATA_DIR / "qdas.sqlite3"
BACKUP_DIR = DATA_DIR / "backups"


def main() -> None:
    if not SOURCE.is_file():
        raise SystemExit(f"Banco não encontrado: {SOURCE}")
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    target = BACKUP_DIR / f"qdas-{datetime.now().strftime('%Y%m%d-%H%M%S')}.sqlite3"
    with sqlite3.connect(SOURCE) as source, sqlite3.connect(target) as backup:
        source.backup(backup)
    print(f"Backup concluído: {target}")


if __name__ == "__main__":
    main()
