@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
  py -3 backup_database.py
) else (
  python backup_database.py
)

if errorlevel 1 pause
