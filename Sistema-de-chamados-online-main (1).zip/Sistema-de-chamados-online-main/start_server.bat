@echo off
setlocal
cd /d "%~dp0"

if not exist "dist\index.html" (
  echo A interface ainda nao foi compilada.
  echo Em um computador com Node.js, execute: npm install ^&^& npm run build
  echo Depois copie a pasta dist para este servidor.
  pause
  exit /b 1
)

if not defined QDAS_PUBLIC_URL set "QDAS_PUBLIC_URL=http://%COMPUTERNAME%:8000"
where py >nul 2>nul
if not errorlevel 1 goto :use_py
where python >nul 2>nul
if not errorlevel 1 goto :use_python
set "PYTHON_COMMAND="
goto :check_server

:use_py
set "PYTHON_COMMAND=py -3"
goto :prepare_outlook

:use_python
set "PYTHON_COMMAND=python"

:prepare_outlook
%PYTHON_COMMAND% prepare_outlook.py
if errorlevel 1 echo Outlook indisponivel. O servidor iniciara sem notificacoes por email ate configurar o Outlook.

:check_server
curl.exe --noproxy "*" --silent --fail http://127.0.0.1:8000/api/health >nul 2>nul
if not errorlevel 1 goto :open_app
if not defined PYTHON_COMMAND goto :python_missing
start "Q-DAS Python Server" cmd /k "%PYTHON_COMMAND% server.py <nul"

set "SERVER_READY="
for /L %%I in (1,1,20) do (
  curl.exe --noproxy "*" --silent --fail http://127.0.0.1:8000/api/health >nul 2>nul
  if not errorlevel 1 (
    set "SERVER_READY=1"
    goto :open_app
  )
  timeout /t 1 /nobreak >nul
)

echo O servidor nao respondeu em http://localhost:8000.
echo Verifique se a porta 8000 ja esta sendo usada e tente novamente.
pause
exit /b 1

:python_missing
echo Python 3 nao encontrado. Instale Python 3 ou solicite apoio da TI.
pause
exit /b 1

:open_app
echo Abrindo http://localhost:8000
start "" "http://localhost:8000"
exit /b 0
