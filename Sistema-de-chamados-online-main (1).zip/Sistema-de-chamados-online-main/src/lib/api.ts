export type AppUser = {
  id: string;
  np: string;
  name: string;
  admin: boolean;
  support: boolean;
};

export async function apiRequest<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  if (init.body) headers.set("Content-Type", "application/json");
  const response = await fetch(`/api${path}`, {
    ...init,
    headers,
    credentials: "same-origin",
  });
  const payload: unknown = await response.json().catch(() => null);
  if (!response.ok) {
    const message =
      payload &&
      typeof payload === "object" &&
      "error" in payload &&
      typeof payload.error === "string"
        ? payload.error
        : `Erro do servidor (${response.status}).`;
    throw new Error(message);
  }
  return payload as T;
}

export function postJson<T>(path: string, data: unknown): Promise<T> {
  return apiRequest<T>(path, { method: "POST", body: JSON.stringify(data) });
}
