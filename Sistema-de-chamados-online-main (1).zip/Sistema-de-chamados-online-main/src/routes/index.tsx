import { createFileRoute, Link } from "@tanstack/react-router";
import { Suspense, useEffect, useState } from "react";
import { toast } from "sonner";
import { Monitor, CheckCircle2, Headset, ExternalLink } from "lucide-react";
import { apiRequest, postJson } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { detectComputerName, type TicketTypeConfig } from "@/lib/tickets";
import { useMiniFabricas } from "@/lib/mini-fabricas";
import { ComputerOpenTickets } from "@/components/computer-open-tickets";
import { BrandLogos } from "@/components/brand-logos";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Abrir chamado Q-DAS" },
      { name: "description", content: "Abra um chamado de suporte para o sistema Q-DAS." },
      { property: "og:title", content: "Abrir chamado Q-DAS" },
      { property: "og:description", content: "Abra um chamado de suporte para o sistema Q-DAS." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Index,
});

const PRIVACY_POLICY_VERSION = "2026-11-06";

const FIELD_NOTICES: Record<string, string> = {
  computer_name_maquina: "Usado para identificar a máquina deste chamado.",
  nome: "Usado somente para identificar a conta solicitada no Q-DAS.",
  np: "Usado somente para solicitar o cadastro da conta na plataforma Q-DAS.",
  usuario: "Nome ou NP usado para identificar o usuário neste chamado.",
};

function Index() {
  const {
    data: miniFabricas = [],
    isPending: loadingFactories,
    isError: factoriesFailed,
    refetch: reloadFactories,
  } = useMiniFabricas();
  const [detected, setDetected] = useState("");
  const [mode, setMode] = useState<"this" | "other">("this");
  const [other, setOther] = useState("");
  const [ticketTypes, setTicketTypes] = useState<TicketTypeConfig[]>([]);
  const [type, setType] = useState<string | null>(null);
  const [details, setDetails] = useState<Record<string, string>>({});
  const [requester, setRequester] = useState("");
  const [description, setDescription] = useState("");
  const [miniFabrica, setMiniFabrica] = useState("");
  const [sending, setSending] = useState(false);
  const [done, setDone] = useState<number | null>(null);
  const [lookupComputer, setLookupComputer] = useState("");
  const [detectingComputer, setDetectingComputer] = useState(true);
  const [privacyAccepted, setPrivacyAccepted] = useState(false);
  const selectedType = ticketTypes.find((ticketType) => ticketType.id === type);

  useEffect(() => {
    apiRequest<TicketTypeConfig[]>("/ticket-types")
      .then(setTicketTypes)
      .catch((error: unknown) => {
        toast.error(
          error instanceof Error
            ? "Não foi possível carregar os tipos de chamado: " + error.message
            : "Não foi possível carregar os tipos de chamado.",
        );
      });
  }, []);

  useEffect(() => {
    let active = true;
    const fromLink = detectComputerName(window.location.search, null);
    const previouslyUsed = localStorage.getItem("qdas_pc");

    apiRequest<{ computer_name: string | null }>("/client-computer")
      .then(({ computer_name }) => {
        if (!active) return;
        const name = fromLink || computer_name || previouslyUsed || "";
        setDetected(name);
        if (name) localStorage.setItem("qdas_pc", name);
        else setMode("other");
      })
      .catch((error: unknown) => {
        if (!active) return;
        console.warn("Não foi possível identificar o computador pela rede.", error);
        const name = fromLink || previouslyUsed || "";
        setDetected(name);
        if (name) localStorage.setItem("qdas_pc", name);
        else setMode("other");
      })
      .finally(() => {
        if (active) setDetectingComputer(false);
      });

    return () => {
      active = false;
    };
  }, []);

  const computer = (mode === "this" ? detected : other).trim().toUpperCase();
  useEffect(() => {
    const timer = window.setTimeout(() => setLookupComputer(computer), 350);
    return () => window.clearTimeout(timer);
  }, [computer]);
  const fields = selectedType?.fields ?? [];
  const needsDescription = selectedType?.description_required ?? false;
  const valid =
    computer &&
    type &&
    miniFabricas.includes(miniFabrica) &&
    fields.every((field) => !field.required || details[field.key]?.trim()) &&
    (!needsDescription || description.trim()) &&
    privacyAccepted;

  async function submit() {
    if (!valid || !type) return;
    setSending(true);
    try {
      const clean = {
        ...Object.fromEntries(fields.map((f) => [f.key, (details[f.key] ?? "").trim()])),
        mini_fabrica: miniFabrica,
      };
      const { number } = await postJson<{ number: number }>("/tickets", {
        computer_name: computer,
        ticket_type: type,
        requester_name: requester,
        description,
        details: clean,
        privacy_consent: { accepted: true, version: PRIVACY_POLICY_VERSION },
      });
      setDone(number);
    } catch (error) {
      toast.error(
        error instanceof Error
          ? "Não foi possível abrir o chamado: " + error.message
          : "Não foi possível conectar ao servidor. Verifique a conexão e tente novamente.",
      );
    } finally {
      setSending(false);
    }
  }

  function reset() {
    setDone(null);
    setType(null);
    setDetails({});
    setDescription("");
    setMiniFabrica("");
    setPrivacyAccepted(false);
  }

  return (
    <div className="min-h-screen">
      <header className="header-band">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-6 py-6">
          <div>
            <BrandLogos className="mb-4" />
            <p className="font-mono text-xs uppercase tracking-widest opacity-80">
              Q-DAS · Suporte
            </p>
            <h1 className="text-2xl font-semibold">Abertura de chamado</h1>
          </div>
          <Link
            to="/suporte"
            className="flex items-center gap-2 text-sm opacity-90 hover:opacity-100"
          >
            <Headset className="h-4 w-4" /> Área do suporte
          </Link>
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-6 py-8">
        {done !== null ? (
          <div className="rounded-lg border bg-card p-10 text-center">
            <CheckCircle2 className="mx-auto h-12 w-12 text-success" />
            <h2 className="mt-4 text-xl font-semibold">Chamado aberto!</h2>
            <p className="mt-2 text-muted-foreground">Número do chamado</p>
            <p className="font-mono text-4xl font-medium text-primary">#{done}</p>
            <Button className="mt-6" onClick={reset}>
              Abrir outro chamado
            </Button>
          </div>
        ) : (
          <div className="space-y-6">
            <section className="rounded-lg border bg-card p-6">
              <h2 className="mb-4 font-semibold">1. Computador</h2>
              <RadioGroup
                value={mode}
                onValueChange={(v) => setMode(v as "this" | "other")}
                className="gap-3"
              >
                <label
                  className={`flex items-center gap-3 rounded-md border p-4 ${!detected ? "opacity-50" : "cursor-pointer"}`}
                >
                  <RadioGroupItem value="this" disabled={!detected || detectingComputer} />
                  <Monitor className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-sm text-muted-foreground">Este computador</p>
                    <p className="font-mono font-medium">
                      {detectingComputer
                        ? "Identificando..."
                        : detected || "Não identificado automaticamente"}
                    </p>
                  </div>
                </label>
                <label className="flex cursor-pointer items-center gap-3 rounded-md border p-4">
                  <RadioGroupItem value="other" />
                  <span className="text-sm font-medium">Outro computador</span>
                </label>
              </RadioGroup>
              {mode === "other" && (
                <div className="mt-4">
                  <Label htmlFor="pc">Computer name</Label>
                  <Input
                    id="pc"
                    className="mt-1 font-mono uppercase"
                    maxLength={64}
                    value={other}
                    onChange={(e) => setOther(e.target.value)}
                    placeholder="Ex.: BRCPS-QD0123"
                  />
                </div>
              )}
            </section>

            {computer && (
              <section className="border-t pt-5" aria-labelledby="open-tickets-heading">
                <h2 id="open-tickets-heading" className="font-semibold">
                  Chamados deste computador
                </h2>
                <p className="mb-2 break-all font-mono text-sm text-muted-foreground">{computer}</p>
                {lookupComputer !== computer ? (
                  <p role="status" className="text-sm text-muted-foreground">
                    Consultando chamados...
                  </p>
                ) : (
                  <Suspense
                    fallback={
                      <p role="status" className="text-sm text-muted-foreground">
                        Consultando chamados...
                      </p>
                    }
                  >
                    <ComputerOpenTickets key={computer} computer={computer} />
                  </Suspense>
                )}
              </section>
            )}

            {computer && (
              <section className="rounded-lg border bg-card p-6">
                <h2 className="mb-4 font-semibold">2. Tipo de chamado</h2>
                <Select
                  value={type ?? ""}
                  onValueChange={(v) => {
                    setType(v);
                    setDetails({});
                  }}
                >
                  <SelectTrigger aria-label="Tipo de chamado">
                    <SelectValue placeholder="Selecione o tipo de chamado" />
                  </SelectTrigger>
                  <SelectContent>
                    {ticketTypes.map((ticketType) => (
                      <SelectItem key={ticketType.id} value={ticketType.id}>
                        {ticketType.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {selectedType && (
                  <p className="mt-2 text-sm text-muted-foreground">{selectedType.hint}</p>
                )}
              </section>
            )}

            {computer && type && (
              <section className="space-y-4 rounded-lg border bg-card p-6">
                <h2 className="font-semibold">3. Informações</h2>
                <div>
                  <Label>Mini fábrica *</Label>
                  <Select value={miniFabrica} onValueChange={setMiniFabrica}>
                    <SelectTrigger
                      className="mt-1"
                      aria-label="Mini fábrica"
                      disabled={loadingFactories || factoriesFailed}
                    >
                      <SelectValue
                        placeholder={
                          loadingFactories ? "Carregando..." : "Selecione a mini fábrica"
                        }
                      />
                    </SelectTrigger>
                    <SelectContent>
                      {miniFabricas.map((m) => (
                        <SelectItem key={m} value={m}>
                          {m}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {factoriesFailed && (
                    <div className="mt-2 text-sm text-destructive">
                      Não foi possível carregar as mini fábricas.{" "}
                      <Button variant="ghost" size="sm" onClick={() => reloadFactories()}>
                        Tentar novamente
                      </Button>
                    </div>
                  )}
                </div>
                {fields.map((f) => (
                  <div key={f.key}>
                    <Label>
                      {f.label} {f.required ? "*" : "(opcional)"}
                    </Label>
                    <Input
                      className="mt-1"
                      maxLength={120}
                      value={details[f.key] ?? ""}
                      onChange={(e) => setDetails({ ...details, [f.key]: e.target.value })}
                    />
                    {FIELD_NOTICES[f.key] && (
                      <p className="mt-1 text-xs text-muted-foreground">{FIELD_NOTICES[f.key]}</p>
                    )}
                  </div>
                ))}
                <div>
                  <Label>Seu nome (solicitante)</Label>
                  <Input
                    className="mt-1"
                    maxLength={120}
                    value={requester}
                    onChange={(e) => setRequester(e.target.value)}
                  />
                  <p className="mt-1 text-xs text-muted-foreground">
                    Usado somente para contato caso o suporte precise pedir informações adicionais.
                  </p>
                </div>
                <div>
                  <Label>Descrição {needsDescription ? "*" : "(opcional)"}</Label>
                  <Textarea
                    className="mt-1"
                    maxLength={2000}
                    rows={4}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder={
                      type === "mascara_errada"
                        ? "Qual máscara está errada e o que deveria aparecer?"
                        : type === "qdas_inativo"
                          ? "Descreva o que acontece quando tenta abrir ou usar o Q-DAS"
                          : type === "outros"
                            ? "Descreva o que você precisa"
                            : ""
                    }
                  />
                </div>
                <div className="space-y-3 rounded-md border p-4">
                  <p className="text-sm font-medium">Privacidade dos seus dados</p>
                  <p className="text-sm text-muted-foreground">
                    Informe apenas os dados necessários para atender ao chamado. Não inclua senhas
                    ou dados pessoais que não foram solicitados.
                  </p>
                  <a
                    href="/politica-privacidade.html"
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 text-sm font-medium text-primary underline underline-offset-4"
                  >
                    Abrir Política de Privacidade
                    <ExternalLink className="h-4 w-4" />
                  </a>
                  <p className="text-xs text-muted-foreground">
                    Versão da política aceita: {PRIVACY_POLICY_VERSION}
                  </p>
                  <label className="flex cursor-pointer items-start gap-3 text-sm">
                    <input
                      type="checkbox"
                      className="mt-1"
                      checked={privacyAccepted}
                      onChange={(event) => setPrivacyAccepted(event.target.checked)}
                      required
                    />
                    <span>
                      Li e estou ciente do Aviso de Privacidade e de como os dados necessários a
                      este chamado serão tratados.
                    </span>
                  </label>
                </div>
                <Button size="lg" className="w-full" disabled={!valid || sending} onClick={submit}>
                  {sending ? "Enviando..." : "Abrir chamado"}
                </Button>
              </section>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
