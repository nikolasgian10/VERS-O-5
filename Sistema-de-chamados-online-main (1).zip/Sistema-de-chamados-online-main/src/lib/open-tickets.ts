import { queryOptions } from "@tanstack/react-query";
import { apiRequest } from "@/lib/api";

export function computerOpenTicketsOptions(computer: string) {
  const normalized = computer.trim().toUpperCase();
  return queryOptions({
    queryKey: ["computer-open-tickets", normalized],
    queryFn: async () => {
      try {
        const tickets = await apiRequest<
          {
            number: number;
            ticket_type: string;
            status: string;
            created_at: string;
            public_notes: { note: string; changed_at: string }[];
          }[]
        >(`/computers/${encodeURIComponent(normalized)}/tickets`);
        return { tickets, failed: false };
      } catch {
        return { tickets: [], failed: true };
      }
    },
    staleTime: 0,
    refetchInterval: 30_000,
  });
}
