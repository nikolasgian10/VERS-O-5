import { queryOptions, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/api";

export function normalizeMiniFabrica(value: string) {
  return value.trim().toUpperCase();
}

export const miniFabricasOptions = queryOptions({
  queryKey: ["mini-fabricas"],
  queryFn: () => apiRequest<string[]>("/mini-fabricas"),
  staleTime: 0,
  refetchOnWindowFocus: true,
});

export function useMiniFabricas() {
  return useQuery(miniFabricasOptions);
}
