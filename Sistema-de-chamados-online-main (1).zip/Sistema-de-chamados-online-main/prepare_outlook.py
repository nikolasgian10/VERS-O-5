from __future__ import annotations

import importlib
import subprocess
import sys
import traceback
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def _load_outlook_com():
    try:
        import pythoncom
        from win32com.client import Dispatch
    except ImportError:
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "pip",
                "install",
                "-r",
                str(ROOT / "requirements-windows.txt"),
            ],
            check=False,
        )
        if result.returncode:
            raise RuntimeError(
                "Não foi possível instalar pywin32. Confira a conexão e o log do pip."
            )
        importlib.invalidate_caches()
        import pythoncom
        from win32com.client import Dispatch

    return pythoncom, Dispatch


def start_outlook() -> None:
    if sys.platform != "win32":
        raise RuntimeError("A automação por Outlook COM só funciona no Windows.")

    pythoncom, dispatch = _load_outlook_com()
    pythoncom.CoInitialize()
    try:
        outlook = dispatch("Outlook.Application")
        inbox = outlook.GetNamespace("MAPI").GetDefaultFolder(6)
        inbox.GetExplorer().Display()
    finally:
        pythoncom.CoUninitialize()


def main() -> int:
    log_path = ROOT / "data" / "logs" / "outlook_startup.log"
    try:
        start_outlook()
        print("Outlook clássico aberto e pronto para notificações.", flush=True)
        return 0
    except Exception as error:
        message = (
            f"Falha ao preparar Outlook: {error}\n"
            "Abra e configure o Outlook clássico na mesma conta Windows do servidor."
        )
        print(message, file=sys.stderr, flush=True)
        try:
            log_path.parent.mkdir(parents=True, exist_ok=True)
            with log_path.open("a", encoding="utf-8") as log_file:
                from datetime import datetime

                log_file.write(
                    f"{datetime.now().astimezone().isoformat(timespec='seconds')} "
                    f"{message}\n{traceback.format_exc()}\n"
                )
        except OSError as log_error:
            print(f"Não foi possível gravar {log_path}: {log_error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
