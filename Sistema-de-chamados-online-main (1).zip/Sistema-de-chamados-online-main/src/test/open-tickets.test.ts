import { afterEach, describe, expect, it, vi } from "vitest";
import { computerOpenTicketsOptions } from "@/lib/open-tickets";

describe("consulta de chamados do computador selecionado", () => {
  afterEach(() => {
    vi.unstubAllGlobals();
  });
  it("consulta somente o computador selecionado com nome normalizado", async () => {
    const tickets = [
      {
        number: 42,
        ticket_type: "instalacao",
        status: "aberto",
        created_at: "2026-10-30T12:00:00Z",
      },
    ];
    const fetchMock = vi
      .fn()
      .mockResolvedValue(new Response(JSON.stringify(tickets), { status: 200 }));
    vi.stubGlobal("fetch", fetchMock);
    const options = computerOpenTicketsOptions(" pc-42 ");
    const result = await (options.queryFn as () => Promise<unknown>)();
    expect(fetchMock).toHaveBeenCalledWith(
      "/api/computers/PC-42/tickets",
      expect.objectContaining({ credentials: "same-origin" }),
    );
    expect(options.queryKey).toEqual(["computer-open-tickets", "PC-42"]);
    expect(result).toEqual({ tickets, failed: false });
  });
  it("diferencia falha de conexão de computador sem chamados", async () => {
    vi.stubGlobal("fetch", vi.fn().mockRejectedValueOnce(new Error("network")));
    const options = computerOpenTicketsOptions("PC-9");
    expect(await (options.queryFn as () => Promise<unknown>)()).toEqual({
      tickets: [],
      failed: true,
    });
  });
  it("sinaliza erros retornados pela API sem confundir com lista vazia", async () => {
    vi.stubGlobal(
      "fetch",
      vi
        .fn()
        .mockResolvedValueOnce(
          new Response(JSON.stringify({ error: "permission denied" }), { status: 403 }),
        ),
    );
    const options = computerOpenTicketsOptions("PC-9");
    expect(await (options.queryFn as () => Promise<unknown>)()).toEqual({
      tickets: [],
      failed: true,
    });
  });
});
