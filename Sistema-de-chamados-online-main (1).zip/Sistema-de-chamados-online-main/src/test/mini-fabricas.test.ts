import { afterEach, describe, expect, it, vi } from "vitest";
import { miniFabricasOptions, normalizeMiniFabrica } from "@/lib/mini-fabricas";

describe("catálogo de mini fábricas", () => {
  afterEach(() => {
    vi.unstubAllGlobals();
  });
  it("inclui novas mini fábricas retornadas pelo banco", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValue(new Response(JSON.stringify(["MFAN", "MFNOVA"]), { status: 200 }));
    vi.stubGlobal("fetch", fetchMock);
    const queryFn = miniFabricasOptions.queryFn;
    if (typeof queryFn !== "function") throw new Error("Consulta ausente");
    const result = await queryFn({
      queryKey: miniFabricasOptions.queryKey,
      signal: new AbortController().signal,
      meta: undefined,
      client: {} as never,
    });
    expect(result).toEqual(["MFAN", "MFNOVA"]);
    expect(fetchMock).toHaveBeenCalledWith(
      "/api/mini-fabricas",
      expect.objectContaining({ credentials: "same-origin" }),
    );
  });
  it("normaliza novas opções para evitar variações do mesmo cadastro", () => {
    expect(normalizeMiniFabrica("  mfNova  ")).toBe("MFNOVA");
  });
});
