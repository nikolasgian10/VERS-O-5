@echo off
setlocal

rem Configure o endereco do servidor Q-DAS abaixo, sem barra no final.
set "QDAS_SERVER_URL=http://NOME-DO-SERVIDOR:8000"

if not defined COMPUTERNAME (
    echo Nao foi possivel obter o nome deste computador.
    pause
    exit /b 1
)

if "%QDAS_SERVER_URL%"=="http://NOME-DO-SERVIDOR:8000" (
    echo Configure QDAS_SERVER_URL neste arquivo com o endereco do servidor.
    pause
    exit /b 1
)

start "" "%QDAS_SERVER_URL%/?pc=%COMPUTERNAME%"
endlocal
