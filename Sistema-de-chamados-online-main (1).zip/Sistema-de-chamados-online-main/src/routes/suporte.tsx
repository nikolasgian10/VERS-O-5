import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { toast } from "sonner";
import { apiRequest, postJson, type AppUser } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { normalizeNp } from "@/lib/np";
import {
  hasAnyAccess,
  listSupportUsers,
  createSupportUser,
  removeSupportUser,
  setupFirstAdmin,
} from "@/lib/support-users.functions";
import {
  countByMiniFabrica,
  DETAIL_LABEL,
  SELECTABLE_STATUSES,
  STATUS_LABEL,
  STATUS_REQUIRES_NOTE,
  TICKET_TYPES,
  type TicketTypeConfig,
  type TicketStatus,
  type TicketType,
} from "@/lib/tickets";
import { useMiniFabricas } from "@/lib/mini-fabricas";
import { MiniFabricaManager } from "@/components/mini-fabrica-manager";
import { BrandLogos } from "@/components/brand-logos";

export const Route = createFileRoute("/suporte")({
  head: () => ({
    meta: [
      { title: "Gestão de chamados Q-DAS" },
      {
        name: "description",
        content: "Painel da equipe de suporte para gerenciar chamados Q-DAS.",
      },
      { property: "og:title", content: "Gestão de chamados Q-DAS" },
      {
        property: "og:description",
        content: "Painel da equipe de suporte para gerenciar chamados Q-DAS.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Suporte,
});

type Ticket = {
  id: string;
  number: number;
  computer_name: string;
  ticket_type: string;
  requester_name: string | null;
  description: string | null;
  details: Record<string, string>;
  status: string;
  assignee: string | null;
  support_notes: string | null;
  privacy_policy_version: string;
  privacy_accepted_at: string;
  status_history: {
    status: string;
    assignee: string | null;
    note: string | null;
    is_public: boolean;
    changed_at: string;
    changed_by: string;
  }[];
  created_at: string;
};

const STATUS_STYLE: Record<string, string> = {
  aberto: "bg-accent text-accent-foreground",
  em_analise: "bg-secondary text-secondary-foreground",
  em_andamento: "bg-primary text-primary-foreground",
  em_execucao: "bg-primary/80 text-primary-foreground",
  resolvido: "bg-success text-primary-foreground",
  cancelado: "bg-muted text-muted-foreground",
};

function Suporte() {
  const [session, setSession] = useState<AppUser | null>(null);
  const [ready, setReady] = useState(false);
  const [accessSetup, setAccessSetup] = useState<"checking" | "needed" | "ready" | "error">(
    "checking",
  );
  const [setupAttempt, setSetupAttempt] = useState(0);
  useEffect(() => {
    let active = true;
    apiRequest<{ user: AppUser | null }>("/me")
      .then(({ user }) => {
        if (!active) return;
        setSession(user);
        setReady(true);
      })
      .catch(() => {
        if (!active) return;
        toast.error(
          "Não foi possível verificar sua sessão. Verifique a conexão e tente novamente.",
        );
        setReady(true);
      });
    hasAnyAccess()
      .then((hasAccess) => {
        if (active) setAccessSetup(hasAccess ? "ready" : "needed");
      })
      .catch(() => {
        if (!active) return;
        setAccessSetup("error");
        toast.error("Não foi possível verificar a configuração do acesso administrativo.");
      });
    return () => {
      active = false;
    };
  }, [setupAttempt]);
  async function signOut() {
    try {
      await apiRequest("/logout", { method: "POST" });
      setSession(null);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Não foi possível encerrar a sessão.");
    }
  }
  if (!ready) return null;
  return (
    <div className="min-h-screen">
      <header className="header-band">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
          <div>
            <BrandLogos className="mb-4" />
            <p className="font-mono text-xs uppercase tracking-widest opacity-80">
              Q-DAS · Suporte
            </p>
            <h1 className="text-2xl font-semibold">Gestão de chamados</h1>
          </div>
          <div className="flex items-center gap-4 text-sm">
            <Link to="/" className="opacity-90 hover:opacity-100">
              Abrir chamado
            </Link>
            {session && (
              <button className="opacity-90 hover:opacity-100" onClick={() => void signOut()}>
                Sair
              </button>
            )}
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-6 py-8">
        {session ? (
          <Board session={session} />
        ) : accessSetup === "needed" ? (
          <FirstAdminSetup onCreated={() => setAccessSetup("ready")} />
        ) : accessSetup === "ready" ? (
          <Login onLogin={setSession} />
        ) : accessSetup === "checking" ? (
          <p role="status" className="text-center text-sm text-muted-foreground">
            Verificando configuração...
          </p>
        ) : (
          <div className="mx-auto max-w-md space-y-4 rounded-lg border bg-card p-6 text-center">
            <p role="alert">
              Não foi possível verificar se o acesso administrativo já foi configurado.
            </p>
            <Button variant="outline" onClick={() => setSetupAttempt((attempt) => attempt + 1)}>
              Tentar novamente
            </Button>
          </div>
        )}
      </main>
    </div>
  );
}

function FirstAdminSetup({ onCreated }: { onCreated: () => void }) {
  const [name, setName] = useState("");
  const [np, setNp] = useState("");
  const [password, setPassword] = useState("");
  const [setupToken, setSetupToken] = useState("");
  const [busy, setBusy] = useState(false);

  async function createFirstAdmin() {
    if (busy) return;
    setBusy(true);
    try {
      await setupFirstAdmin({ data: { name, np, password, setupToken } });
      onCreated();
      toast.success("Administrador criado. Entre com o NP e a senha cadastrados.");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Não foi possível criar o administrador.",
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <form
      className="mx-auto max-w-sm space-y-4 rounded-lg border bg-card p-6"
      onSubmit={(event) => {
        event.preventDefault();
        void createFirstAdmin();
      }}
    >
      <div>
        <h2 className="text-lg font-semibold">Configurar primeiro administrador</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Este cadastro só fica disponível enquanto não houver acessos configurados.
        </p>
      </div>
      <div>
        <Label htmlFor="first-admin-name">Nome</Label>
        <Input
          id="first-admin-name"
          className="mt-1"
          autoComplete="name"
          maxLength={100}
          value={name}
          onChange={(event) => setName(event.target.value)}
          required
        />
      </div>
      <div>
        <Label htmlFor="first-admin-np">NP</Label>
        <Input
          id="first-admin-np"
          className="mt-1 font-mono"
          autoComplete="username"
          maxLength={40}
          value={np}
          onChange={(event) => setNp(event.target.value)}
          required
        />
      </div>
      <div>
        <Label htmlFor="first-admin-password">Senha</Label>
        <Input
          id="first-admin-password"
          className="mt-1"
          type="password"
          autoComplete="new-password"
          minLength={4}
          maxLength={128}
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          required
        />
      </div>
      <div>
        <Label htmlFor="first-admin-setup-token">Código de configuração</Label>
        <Input
          id="first-admin-setup-token"
          className="mt-1"
          type="password"
          autoComplete="off"
          maxLength={256}
          value={setupToken}
          onChange={(event) => setSetupToken(event.target.value)}
          required
        />
      </div>
      <Button
        type="submit"
        className="w-full"
        disabled={
          busy || !name.trim() || !np.trim() || password.length < 4 || setupToken.length < 32
        }
      >
        {busy ? "Configurando..." : "Criar administrador"}
      </Button>
    </form>
  );
}

function Login({ onLogin }: { onLogin: (user: AppUser) => void }) {
  const [np, setNp] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  async function go() {
    const n = normalizeNp(np);
    if (!n) {
      toast.error("NP inválido.");
      return;
    }
    setBusy(true);
    try {
      const { user } = await postJson<{ user: AppUser }>("/login", { np: n, password });
      onLogin(user);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Não foi possível entrar.");
    } finally {
      setBusy(false);
    }
  }
  return (
    <form
      className="mx-auto max-w-sm space-y-4 rounded-lg border bg-card p-6"
      onSubmit={(e) => {
        e.preventDefault();
        go();
      }}
    >
      <h2 className="text-lg font-semibold">Entrar</h2>
      <div>
        <Label htmlFor="np">NP</Label>
        <Input
          id="np"
          className="mt-1 font-mono"
          maxLength={40}
          inputMode="text"
          autoComplete="username"
          value={np}
          onChange={(e) => setNp(e.target.value)}
        />
      </div>
      <div>
        <Label htmlFor="pw">Senha</Label>
        <Input
          id="pw"
          className="mt-1"
          type="password"
          autoComplete="current-password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </div>
      <Button type="submit" className="w-full" disabled={busy || !np || !password}>
        {busy ? "Entrando..." : "Entrar"}
      </Button>
    </form>
  );
}

function Users({ meId }: { meId: string }) {
  const [list, setList] = useState<{ id: string; np: string; name: string; admin: boolean }[]>([]);
  const [name, setName] = useState("");
  const [np, setNp] = useState("");
  const [pw, setPw] = useState("");
  const [admin, setAdmin] = useState(false);
  const load = useCallback(
    () =>
      listSupportUsers()
        .then(setList)
        .catch((error) =>
          toast.error(
            error instanceof Error ? error.message : "Não foi possível carregar os usuários.",
          ),
        ),
    [],
  );
  useEffect(() => {
    load();
  }, [load]);
  async function add() {
    try {
      await createSupportUser({ data: { name, np, password: pw, admin } });
      toast.success("Usuário criado");
      setName("");
      setNp("");
      setPw("");
      setAdmin(false);
      load();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Não foi possível criar o usuário.");
    }
  }
  async function remove(id: string) {
    if (!confirm("Remover este acesso?")) return;
    try {
      await removeSupportUser({ data: { id } });
      load();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Não foi possível remover o acesso.");
    }
  }
  return (
    <section className="space-y-4 rounded-lg border bg-card p-6">
      <h2 className="font-semibold">Usuários do suporte</h2>
      <div className="flex flex-wrap items-end gap-3">
        <div>
          <Label>Nome</Label>
          <Input
            className="mt-1 w-56"
            maxLength={100}
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </div>
        <div>
          <Label>NP</Label>
          <Input
            className="mt-1 w-36 font-mono"
            maxLength={40}
            value={np}
            onChange={(e) => setNp(e.target.value)}
          />
        </div>
        <div>
          <Label>Senha</Label>
          <Input
            className="mt-1 w-36"
            type="password"
            maxLength={128}
            value={pw}
            onChange={(e) => setPw(e.target.value)}
          />
        </div>
        <label className="flex items-center gap-2 pb-2 text-sm">
          <input type="checkbox" checked={admin} onChange={(e) => setAdmin(e.target.checked)} />{" "}
          Administrador
        </label>
        <Button onClick={add} disabled={!name.trim() || !np.trim() || pw.length < 4}>
          Criar usuário
        </Button>
      </div>
      <table className="w-full text-sm">
        <thead className="text-left text-muted-foreground">
          <tr>
            <th className="p-2">Nome</th>
            <th className="p-2">NP</th>
            <th className="p-2">Perfil</th>
            <th />
          </tr>
        </thead>
        <tbody>
          {list.map((u) => (
            <tr key={u.id} className="border-t">
              <td className="p-2">{u.name || "—"}</td>
              <td className="p-2 font-mono">{u.np}</td>
              <td className="p-2">{u.admin ? "Administrador" : "Suporte"}</td>
              <td className="p-2 text-right">
                {u.id !== meId && (
                  <Button variant="outline" size="sm" onClick={() => remove(u.id)}>
                    Remover
                  </Button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );
}

function Board({ session }: { session: AppUser }) {
  const {
    data: miniFabricas = [],
    isError: factoriesFailed,
    refetch: reloadFactories,
  } = useMiniFabricas();
  const [isSupport, setIsSupport] = useState<boolean | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [ticketTypes, setTicketTypes] = useState<TicketTypeConfig[]>([]);
  const [status, setStatus] = useState<string>("ativos");
  const [type, setType] = useState<string>("todos");
  const [q, setQ] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [mf, setMf] = useState("todas");
  const [open, setOpen] = useState<Ticket | null>(null);
  const [printContainer, setPrintContainer] = useState<HTMLElement | null>(null);

  useEffect(() => {
    setPrintContainer(document.body);
  }, []);

  const load = useCallback(async () => {
    try {
      setTickets(await apiRequest<Ticket[]>("/tickets"));
    } catch (error) {
      toast.error(
        error instanceof Error
          ? "Não foi possível carregar os chamados: " + error.message
          : "Não foi possível conectar ao servidor para carregar os chamados.",
      );
    }
  }, []);

  const loadTicketTypes = useCallback(async () => {
    try {
      setTicketTypes(await apiRequest<TicketTypeConfig[]>("/ticket-types"));
    } catch (error) {
      toast.error(
        error instanceof Error
          ? "Não foi possível carregar os tipos de chamado: " + error.message
          : "Não foi possível carregar os tipos de chamado.",
      );
    }
  }, []);

  useEffect(() => {
    load();
    loadTicketTypes();
    setIsSupport(session.support);
    setIsAdmin(session.admin);
  }, [session.id, session.support, session.admin, load, loadTicketTypes]);

  const ticketTypeLabel = (id: string) =>
    ticketTypes.find((ticketType) => ticketType.id === id)?.label ??
    TICKET_TYPES[id as TicketType]?.label ??
    id;

  const inPeriod = useMemo(() => {
    const start = from ? new Date(`${from}T00:00:00`).getTime() : -Infinity;
    const end = to ? new Date(`${to}T23:59:59.999`).getTime() : Infinity;
    return tickets.filter((t) => {
      const d = new Date(t.created_at).getTime();
      return d >= start && d <= end;
    });
  }, [tickets, from, to]);

  /** Contagem por mini fábrica no período: não muda ao escolher uma delas. */
  const mfCounts = useMemo(() => countByMiniFabrica(inPeriod), [inPeriod]);

  const mfFiltered = useMemo(
    () => inPeriod.filter((t) => (mf === "todas" ? true : t.details?.["mini_fabrica"] === mf)),
    [inPeriod, mf],
  );

  const list = useMemo(
    () =>
      mfFiltered.filter(
        (t) =>
          (status === "todos" ||
            (status === "ativos"
              ? !["resolvido", "cancelado"].includes(t.status)
              : t.status === status)) &&
          (type === "todos" || t.ticket_type === type) &&
          (!q ||
            `${t.number} ${t.computer_name} ${JSON.stringify(t.details)}`
              .toLowerCase()
              .includes(q.toLowerCase())),
      ),
    [mfFiltered, status, type, q],
  );

  const counts = useMemo(() => {
    const c: Record<string, number> = {};
    mfFiltered.forEach((t) => (c[t.status] = (c[t.status] ?? 0) + 1));
    return c;
  }, [mfFiltered]);

  if (isSupport === null) return null;
  if (!isSupport)
    return (
      <div className="mx-auto max-w-md rounded-lg border bg-card p-6 text-center">
        <h2 className="font-semibold">Acesso restrito</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Sua conta ainda não tem permissão de suporte. Peça a um administrador para liberar.
        </p>
      </div>
    );

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end gap-3 rounded-lg border bg-card p-4">
        <div>
          <Label htmlFor="from">De</Label>
          <Input
            id="from"
            type="date"
            className="mt-1 w-44"
            value={from}
            onChange={(e) => setFrom(e.target.value)}
          />
        </div>
        <div>
          <Label htmlFor="to">Até</Label>
          <Input
            id="to"
            type="date"
            className="mt-1 w-44"
            value={to}
            onChange={(e) => setTo(e.target.value)}
          />
        </div>
        <div>
          <Label>Mini fábrica</Label>
          <Select value={mf} onValueChange={setMf}>
            <SelectTrigger className="mt-1 w-40" aria-label="Mini fábrica">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todas">Todas</SelectItem>
              {miniFabricas.map((m) => (
                <SelectItem key={m} value={m}>
                  {m}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        {factoriesFailed && (
          <Button variant="outline" onClick={() => reloadFactories()}>
            Recarregar mini fábricas
          </Button>
        )}
        {(from || to || mf !== "todas") && (
          <Button
            variant="ghost"
            onClick={() => {
              setFrom("");
              setTo("");
              setMf("todas");
            }}
          >
            Limpar filtros
          </Button>
        )}
        <p className="pb-2 text-sm text-muted-foreground">
          {mfFiltered.length} chamado(s) no filtro
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        {SELECTABLE_STATUSES.map((s) => (
          <button
            key={s}
            onClick={() => setStatus(s)}
            className={`rounded-lg border bg-card p-6 text-left ${status === s ? "ring-2 ring-primary" : ""}`}
          >
            <p className="text-base text-muted-foreground">{STATUS_LABEL[s]}</p>
            <p className="mt-2 font-mono text-5xl font-medium">{counts[s] ?? 0}</p>
          </button>
        ))}
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <p className="text-sm text-muted-foreground">Mini fábrica:</p>
        <button
          onClick={() => setMf("todas")}
          className={`rounded-full border px-3 py-1.5 text-sm ${mf === "todas" ? "border-primary bg-primary text-primary-foreground" : "bg-card hover:bg-muted"}`}
        >
          Todas <span className="font-mono">{inPeriod.length}</span>
        </button>
        {miniFabricas.map((m) => (
          <Button
            variant="outline"
            key={m}
            onClick={() => setMf(m)}
            className={`rounded-full border px-3 py-1.5 text-sm ${mf === m ? "border-primary bg-primary text-primary-foreground" : "bg-card hover:bg-muted"}`}
          >
            {m} <span className="font-mono">{mfCounts[m] ?? 0}</span>
          </Button>
        ))}
      </div>

      <div className="flex flex-wrap gap-3">
        <Input
          className="max-w-xs"
          placeholder="Buscar nº, computer name, nome..."
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-44">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ativos">Abertos + andamento</SelectItem>
            <SelectItem value="todos">Todos os status</SelectItem>
            {SELECTABLE_STATUSES.map((k) => (
              <SelectItem key={k} value={k}>
                {STATUS_LABEL[k]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={type} onValueChange={setType}>
          <SelectTrigger className="w-56">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos os tipos</SelectItem>
            {ticketTypes.map((ticketType) => (
              <SelectItem key={ticketType.id} value={ticketType.id}>
                {ticketType.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button variant="outline" onClick={() => window.print()}>
          Imprimir / gerar PDF
        </Button>
        <Button variant="outline" onClick={load}>
          Atualizar
        </Button>
      </div>

      <div className="overflow-hidden rounded-lg border bg-card">
        <table className="w-full text-sm">
          <thead className="bg-muted text-left text-muted-foreground">
            <tr>
              <th className="p-3">Nº</th>
              <th className="p-3">Computador</th>
              <th className="p-3">Mini fábrica</th>
              <th className="p-3">Tipo</th>
              <th className="p-3">Responsável</th>
              <th className="p-3">Aberto em</th>
              <th className="p-3">Status</th>
            </tr>
          </thead>
          <tbody>
            {list.map((t) => (
              <tr
                key={t.id}
                onClick={() => setOpen(t)}
                className="cursor-pointer border-t hover:bg-muted/50"
              >
                <td className="p-3 font-mono">#{t.number}</td>
                <td className="p-3 font-mono">{t.computer_name}</td>
                <td className="p-3 font-mono">{t.details?.["mini_fabrica"] ?? "—"}</td>
                <td className="p-3">{ticketTypeLabel(t.ticket_type)}</td>
                <td className="p-3">{t.assignee ?? "—"}</td>
                <td className="p-3">{new Date(t.created_at).toLocaleString("pt-BR")}</td>
                <td className="p-3">
                  <Badge className={STATUS_STYLE[t.status]}>
                    {STATUS_LABEL[t.status as TicketStatus]}
                  </Badge>
                </td>
              </tr>
            ))}
            {!list.length && (
              <tr>
                <td colSpan={7} className="p-8 text-center text-muted-foreground">
                  Nenhum chamado.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {printContainer &&
        createPortal(
          <section className="ticket-print">
            <h1>Lista de chamados — Q-DAS Suporte</h1>
            <p>
              Gerado em {new Date().toLocaleString("pt-BR")}
              {session.np ? ` por NP ${session.np}` : ""}
            </p>
            <p>
              <b>Mini fábrica:</b> {mf === "todas" ? "Todas" : mf}
            </p>
            <p>
              <b>Status:</b>{" "}
              {status === "todos"
                ? "Todos os status"
                : status === "ativos"
                  ? "Abertos + andamento"
                  : (STATUS_LABEL[status as TicketStatus] ?? status)}
            </p>
            <p>
              <b>Tipo:</b> {type === "todos" ? "Todos" : ticketTypeLabel(type)}
            </p>
            <p>
              <b>Período:</b> {from || "início"} até {to || "hoje"}
            </p>
            {q && (
              <p>
                <b>Busca:</b> {q}
              </p>
            )}
            <p>
              <b>Total:</b> {list.length} chamado(s)
            </p>
            <table>
              <thead>
                <tr>
                  <th>Nº</th>
                  <th>Computador</th>
                  <th>Mini fábrica</th>
                  <th>Tipo</th>
                  <th>Responsável</th>
                  <th>Aberto em</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {list.map((t) => (
                  <tr key={t.id}>
                    <td>#{t.number}</td>
                    <td>{t.computer_name}</td>
                    <td>{t.details?.["mini_fabrica"] ?? "—"}</td>
                    <td>{ticketTypeLabel(t.ticket_type)}</td>
                    <td>{t.assignee ?? "—"}</td>
                    <td>{new Date(t.created_at).toLocaleString("pt-BR")}</td>
                    <td>{STATUS_LABEL[t.status as TicketStatus] ?? t.status}</td>
                  </tr>
                ))}
                {!list.length && (
                  <tr>
                    <td colSpan={7}>Nenhum chamado.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </section>,
          printContainer,
        )}

      {isAdmin && <TicketTypesManager types={ticketTypes} onChanged={loadTicketTypes} />}
      {isAdmin && <MiniFabricaManager />}
      {isAdmin && <Users meId={session.id} />}

      {open && (
        <TicketDialog
          ticket={open}
          me={session.name || session.np}
          ticketTypeLabel={ticketTypeLabel(open.ticket_type)}
          fieldLabels={Object.fromEntries(
            (
              ticketTypes.find((ticketType) => ticketType.id === open.ticket_type)?.fields ?? []
            ).map((field) => [field.key, field.label]),
          )}
          onClose={() => setOpen(null)}
          onSaved={() => {
            setOpen(null);
            load();
          }}
        />
      )}
    </div>
  );
}

function TicketTypesManager({
  types,
  onChanged,
}: {
  types: TicketTypeConfig[];
  onChanged: () => Promise<void>;
}) {
  const [editingId, setEditingId] = useState("__new__");
  const [label, setLabel] = useState("");
  const [hint, setHint] = useState("");
  const [fields, setFields] = useState<TicketTypeConfig["fields"]>([]);
  const [descriptionRequired, setDescriptionRequired] = useState(false);
  const [fieldNumber, setFieldNumber] = useState(1);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);

  function selectType(id: string) {
    setEditingId(id);
    const config = types.find((ticketType) => ticketType.id === id);
    setLabel(config?.label ?? "");
    setHint(config?.hint ?? "");
    setFields(config?.fields ?? []);
    setDescriptionRequired(config?.description_required ?? false);
  }

  function addField() {
    let number = fieldNumber;
    while (fields.some((field) => field.key === `campo_${number}`)) number += 1;
    const key = `campo_${number}`;
    setFieldNumber(number + 1);
    setFields((current) => [...current, { key, label: "", required: false }]);
  }

  async function save() {
    if (saving) return;
    setSaving(true);
    try {
      const body = {
        label,
        hint,
        fields,
        description_required: descriptionRequired,
      };
      const saved = await apiRequest<TicketTypeConfig>(
        editingId === "__new__"
          ? "/ticket-types"
          : `/ticket-types/${encodeURIComponent(editingId)}`,
        {
          method: editingId === "__new__" ? "POST" : "PUT",
          body: JSON.stringify(body),
        },
      );
      await onChanged();
      setEditingId(saved.id);
      setLabel(saved.label);
      setHint(saved.hint);
      setFields(saved.fields);
      setDescriptionRequired(saved.description_required);
      toast.success("Tipo de chamado salvo.");
    } catch (error) {
      toast.error(
        error instanceof Error
          ? "Não foi possível salvar o tipo: " + error.message
          : "Não foi possível salvar o tipo de chamado.",
      );
    } finally {
      setSaving(false);
    }
  }

  async function remove() {
    if (editingId === "__new__" || deleting) return;
    if (!window.confirm(`Excluir o tipo "${label}"? Esta ação não pode ser desfeita.`)) {
      return;
    }
    setDeleting(true);
    try {
      await apiRequest(`/ticket-types/${encodeURIComponent(editingId)}`, {
        method: "DELETE",
      });
      await onChanged();
      setEditingId("__new__");
      setLabel("");
      setHint("");
      setFields([]);
      setDescriptionRequired(false);
      toast.success("Tipo de chamado excluído.");
    } catch (error) {
      toast.error(
        error instanceof Error
          ? "Não foi possível excluir o tipo: " + error.message
          : "Não foi possível excluir o tipo de chamado.",
      );
    } finally {
      setDeleting(false);
    }
  }

  return (
    <section className="space-y-4 rounded-lg border bg-card p-6">
      <div>
        <h2 className="font-semibold">Tipos de chamado e campos</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Defina os campos que serão exibidos na abertura e quais são obrigatórios.
        </p>
      </div>
      <div className="flex flex-wrap items-end gap-3">
        <div className="min-w-60">
          <Label htmlFor="ticket-type-choice">Tipo para editar</Label>
          <select
            id="ticket-type-choice"
            className="mt-1 h-10 w-full rounded-md border bg-background px-3 text-sm"
            value={editingId}
            onChange={(event) => selectType(event.target.value)}
          >
            <option value="__new__">Adicionar novo tipo</option>
            {types.map((ticketType) => (
              <option key={ticketType.id} value={ticketType.id}>
                {ticketType.label}
              </option>
            ))}
          </select>
        </div>
        <Button
          type="button"
          variant="outline"
          onClick={() => {
            setEditingId("__new__");
            setLabel("");
            setHint("");
            setFields([]);
            setDescriptionRequired(false);
          }}
        >
          Novo tipo
        </Button>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <Label htmlFor="ticket-type-label">Nome do tipo *</Label>
          <Input
            id="ticket-type-label"
            className="mt-1"
            maxLength={80}
            value={label}
            onChange={(event) => setLabel(event.target.value)}
          />
        </div>
        <div>
          <Label htmlFor="ticket-type-hint">Orientação (opcional)</Label>
          <Input
            id="ticket-type-hint"
            className="mt-1"
            maxLength={160}
            value={hint}
            onChange={(event) => setHint(event.target.value)}
          />
        </div>
      </div>
      <label className="flex items-center gap-2 text-sm">
        <input
          type="checkbox"
          checked={descriptionRequired}
          onChange={(event) => setDescriptionRequired(event.target.checked)}
        />
        Descrição obrigatória
      </label>
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-medium">Campos adicionais</h3>
          <Button type="button" variant="outline" size="sm" onClick={addField}>
            Adicionar campo
          </Button>
        </div>
        {fields.map((field, index) => (
          <div key={field.key} className="flex flex-wrap items-end gap-3 rounded-md border p-3">
            <div className="min-w-48 flex-1">
              <Label htmlFor={`ticket-field-${field.key}`}>Nome do campo</Label>
              <Input
                id={`ticket-field-${field.key}`}
                className="mt-1"
                maxLength={80}
                value={field.label}
                onChange={(event) =>
                  setFields((current) =>
                    current.map((item, itemIndex) =>
                      itemIndex === index ? { ...item, label: event.target.value } : item,
                    ),
                  )
                }
              />
            </div>
            <label className="flex h-10 items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={field.required}
                onChange={(event) =>
                  setFields((current) =>
                    current.map((item, itemIndex) =>
                      itemIndex === index ? { ...item, required: event.target.checked } : item,
                    ),
                  )
                }
              />
              Obrigatório
            </label>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => setFields((current) => current.filter((_, i) => i !== index))}
            >
              Remover
            </Button>
          </div>
        ))}
      </div>
      <div className="flex flex-wrap gap-2">
        <Button
          type="button"
          onClick={() => void save()}
          disabled={saving || deleting || !label.trim()}
        >
          {saving ? "Salvando..." : "Salvar tipo"}
        </Button>
        {editingId !== "__new__" && (
          <Button
            type="button"
            variant="destructive"
            onClick={() => void remove()}
            disabled={saving || deleting}
          >
            {deleting ? "Excluindo..." : "Excluir tipo"}
          </Button>
        )}
      </div>
    </section>
  );
}

function TicketDialog({
  ticket,
  me,
  ticketTypeLabel,
  fieldLabels,
  onClose,
  onSaved,
}: {
  ticket: Ticket;
  me: string;
  ticketTypeLabel: string;
  fieldLabels: Record<string, string>;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [status, setStatus] = useState(ticket.status);
  const [assignee, setAssignee] = useState(ticket.assignee ?? "");
  const [notes, setNotes] = useState("");
  const [noteIsPublic, setNoteIsPublic] = useState(false);
  const [saving, setSaving] = useState(false);
  const needsNote =
    status !== ticket.status && STATUS_REQUIRES_NOTE.includes(status as TicketStatus);
  async function save() {
    if (needsNote && !notes.trim()) {
      toast.error("Escreva um parecer para o usuário.");
      return;
    }
    if (saving) return;
    setSaving(true);
    try {
      await apiRequest(`/tickets/${encodeURIComponent(ticket.id)}`, {
        method: "PATCH",
        body: JSON.stringify({
          status,
          assignee,
          support_notes: notes,
          note_is_public: noteIsPublic,
        }),
        headers: { "Content-Type": "application/json" },
      });
      toast.success("Chamado atualizado");
      onSaved();
    } catch (error) {
      toast.error(
        error instanceof Error
          ? "Não foi possível atualizar o chamado: " + error.message
          : "Não foi possível conectar ao servidor. O chamado não foi atualizado.",
      );
    } finally {
      setSaving(false);
    }
  }
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent
        className="flex max-h-[calc(100vh-2rem)] w-[calc(100%-2rem)] max-w-lg flex-col gap-0 overflow-hidden p-0"
        style={{ maxHeight: "calc(100dvh - 2rem)" }}
      >
        <DialogHeader className="shrink-0 border-b bg-background px-6 py-4 pr-12 text-left">
          <DialogTitle>
            Chamado #{ticket.number} · {ticketTypeLabel}
          </DialogTitle>
        </DialogHeader>
        <div
          className="min-h-0 flex-1 touch-pan-y overflow-y-auto overscroll-contain px-6 py-4"
          tabIndex={0}
          aria-label="Detalhes e edição do chamado"
        >
          <div className="space-y-4">
            <dl className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <dt className="text-muted-foreground">Computador</dt>
                <dd className="font-mono">{ticket.computer_name}</dd>
              </div>
              <div>
                <dt className="text-muted-foreground">Solicitante</dt>
                <dd>{ticket.requester_name ?? "—"}</dd>
              </div>
              {Object.entries(ticket.details ?? {}).map(([k, v]) => (
                <div key={k}>
                  <dt className="text-muted-foreground">
                    {fieldLabels[k] ?? DETAIL_LABEL[k] ?? k}
                  </dt>
                  <dd>{v}</dd>
                </div>
              ))}
            </dl>
            {ticket.description && (
              <p className="rounded-md bg-muted p-3 text-sm">{ticket.description}</p>
            )}
            <section className="rounded-md border p-3 text-sm">
              <h3 className="font-semibold">Aceite da Política de Privacidade</h3>
              {ticket.privacy_policy_version ? (
                <dl className="mt-2 grid gap-1">
                  <div>
                    <dt className="inline text-muted-foreground">Versão aceita: </dt>
                    <dd className="inline font-mono">{ticket.privacy_policy_version}</dd>
                  </div>
                  <div>
                    <dt className="inline text-muted-foreground">Registrado em: </dt>
                    <dd className="inline">
                      {ticket.privacy_accepted_at
                        ? new Date(ticket.privacy_accepted_at).toLocaleString("pt-BR")
                        : "Data não disponível"}
                    </dd>
                  </div>
                </dl>
              ) : (
                <p className="mt-1 text-muted-foreground">
                  Não há registro de aceite para este chamado.
                </p>
              )}
            </section>
            <section className="space-y-2 rounded-md border p-3">
              <h3 className="text-sm font-semibold">Histórico de pareceres e status</h3>
              {ticket.status_history.length ? (
                <ol className="max-h-48 space-y-3 overflow-y-auto">
                  {[...ticket.status_history].reverse().map((entry, index) => (
                    <li key={`${entry.changed_at}-${index}`} className="border-l-2 pl-3 text-sm">
                      <p className="font-medium">
                        {STATUS_LABEL[entry.status as TicketStatus] ?? entry.status}
                        {entry.changed_by ? ` · ${entry.changed_by}` : ""}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(entry.changed_at).toLocaleString("pt-BR")}
                      </p>
                      {entry.note && (
                        <>
                          <p className="mt-1 whitespace-pre-wrap">{entry.note}</p>
                          <p className="mt-1 text-xs text-muted-foreground">
                            {entry.is_public ? "Público" : "Privado"}
                          </p>
                        </>
                      )}
                    </li>
                  ))}
                </ol>
              ) : (
                <p className="text-sm text-muted-foreground">Nenhuma alteração registrada.</p>
              )}
            </section>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Status</Label>
                <Select
                  value={status}
                  onValueChange={(value) => {
                    setStatus(value);
                    setNotes("");
                    setNoteIsPublic(false);
                  }}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {SELECTABLE_STATUSES.map((k) => (
                      <SelectItem key={k} value={k}>
                        {STATUS_LABEL[k]}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Responsável</Label>
                <div className="mt-1 flex gap-1">
                  <Input value={assignee} onChange={(e) => setAssignee(e.target.value)} />
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-9"
                    onClick={() => setAssignee(me)}
                  >
                    Eu
                  </Button>
                </div>
              </div>
            </div>
            <div>
              <Label>Parecer para o usuário {needsNote ? "*" : "(opcional)"}</Label>
              <Textarea
                className="mt-1"
                rows={3}
                value={notes}
                placeholder={
                  status === "em_andamento" ? "Ex.: Aguardando chegada do cabo até dia 30/10" : ""
                }
                onChange={(e) => {
                  setNotes(e.target.value);
                  if (!e.target.value.trim()) setNoteIsPublic(false);
                }}
              />
              <label className="mt-2 flex items-start gap-2 text-sm">
                <input
                  type="checkbox"
                  className="mt-1 accent-primary"
                  checked={noteIsPublic}
                  disabled={!notes.trim()}
                  onChange={(event) => setNoteIsPublic(event.target.checked)}
                />
                <span>
                  Exibir este parecer publicamente em “Chamados deste computador”
                  <span className="block text-xs text-muted-foreground">
                    Desmarcado, o parecer fica visível somente para a equipe de suporte.
                  </span>
                </span>
              </label>
            </div>
          </div>
        </div>
        <div className="shrink-0 border-t bg-background px-6 py-3">
          <Button
            className="w-full sm:w-auto"
            onClick={save}
            disabled={saving || (needsNote && !notes.trim())}
          >
            {saving ? "Salvando..." : "Salvar"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
